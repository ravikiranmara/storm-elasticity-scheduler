package backtype.storm.scheduler.Elasticity;

public class Config {
	public final static String LOG_PATH = "/tmp/";
	public static String SCHEDULER_TYPE="";
}
